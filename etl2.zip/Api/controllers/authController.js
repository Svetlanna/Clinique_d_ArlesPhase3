import { pool } from '../../../Api/config/db.js';

export const login = async (req, res) => {
    const { login, password } = req.body;

    if (!login || !password) {
        return res.status(400).json({ status: 'error', message: 'Champs requis manquants' });
    }


    try {

        const [rows] = await pool.query(
            'SELECT login, mot_de_passe, role FROM utilisateur WHERE login = ? AND actif = 1',
            [login]
        );

        if (rows.length === 0) {
            return res.status(401).json({ status: 'error', message: 'Identifiants invalides' });
        }

        const user = rows[0];


        if (password !== user.mot_de_passe) {
            return res.status(401).json({ status: 'error', message: 'Identifiants invalides' });
        }


       res.json({
        data: {
            mail: user.login,
            role: user.role,
            mot_de_passe: user.mot_de_passe
        }

        });
    } catch (error) {
        console.error("Erreur serveur :", error);
        res.status(500).json({ status: 'error', message: 'Erreur interne du serveur' });
    }
};